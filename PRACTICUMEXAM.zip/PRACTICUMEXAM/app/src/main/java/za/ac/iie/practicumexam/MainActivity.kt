package za.ac.iie.practicumexam
//ST10493362 THANDI KALUWA
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private val edtSongTitleList = arrayListOf<String>()
    private val edtArtistNameList = arrayListOf<String>()
    private val edtRatingList = arrayListOf<Int>()
    private val edtCommentList = arrayListOf<String>()


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val edtSongTitle = findViewById<EditText>(R.id.edtSongTitle)
        val edtArtistName = findViewById<EditText>(R.id.edtArtistName)
        val edtRating = findViewById<EditText>(R.id.edtRating)
        val edtComment = findViewById<EditText>(R.id.edtComment)

        val btnAddToPlaylist = findViewById<Button>(R.id.btnAddToPlayList)
        val btnNextScreen = findViewById<Button>(R.id.btnNextScreen)
        val btnExit = findViewById<Button>(R.id.btnExit)

        btnAddToPlaylist.setOnClickListener {
            val edtSongTitle = edtSongTitle.text.toString()
            val edtArtistName = edtArtistName.text.toString()
            val edtRating = edtRating.text.toString()
            val edtComment = edtComment.text.toString()

// To make sure all fields are filled in and not left empty
            if (edtSongTitle.isEmpty() || edtArtistName.isEmpty() || edtRating.isEmpty() || edtComment.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            } else {
                try {
                    val edtRating = edtRating.toInt()
                    edtSongTitleList.add(edtSongTitle)
                    edtArtistNameList.add(edtArtistName)
                    edtRatingList.add(edtRating)
                    edtCommentList.add(edtComment)
                    Toast.makeText(this, "Item Added", Toast.LENGTH_SHORT).show()
                } catch (e: NumberFormatException) {
                    Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show()
                }
            }
        }

//When button is clicked it will take user to the next screen
        btnNextScreen.setOnClickListener {
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)

//When button is clicked it will exit/close the app
        btnExit.setOnClickListener {
            finish()

//code is correct but the application keeps on crashing instead of going to the next screen



















                ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
                    val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                    v.setPadding(
                        systemBars.left,
                        systemBars.top,
                        systemBars.right,
                        systemBars.bottom
                    )
                    insets
                }
            }
        }}}