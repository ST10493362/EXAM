package za.ac.iie.practicumexam
//ST10493362 THANDI KALUWA
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity2 : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)

        val btnViewPlaylist = findViewById<Button>(R.id.btnViewPlaylist)
        val btnAverage = findViewById<Button>(R.id.btnAverage)
        val btnMainScreen = findViewById<Button>(R.id.btnMainScreen)

        val edtSongTitleList = intent.getStringArrayListExtra("edtSongTitle") ?: arrayListOf()
        val edtArtistNameList = intent.getIntegerArrayListExtra("edtArtistName") ?: arrayListOf()

        val listView = findViewById<ListView>(R.id.ListView)
        val filteredItems = edtSongTitleList.filterIndexed {index, _ ->
            edtArtistNameList[index] >= 2
        }

//When button is clicked it will take the user to the main screen
        btnMainScreen.setOnClickListener {
            (Intent(this, MainActivity::class.java))
        }


// When button is clicked the songs will be displayed
        btnViewPlaylist.setOnClickListener {
            val intent = Intent(this, MainActivity2::class.java)
            intent.putStringArrayListExtra("Song Title", edtSongTitleList)
            intent.putStringArrayListExtra("Artist Name", edtArtistNameList)
            startActivity(intent)
        }

//When btn average is clicked the average rating will be displayed
        btnAverage.setOnClickListener{

        }

//kotlin.org
        fun main() {
            val edtRating = listOf(1, 2, 3, 4, 5)

            println("Count: ${edtRating.count()}")
            println("Max: ${edtRating.maxOrNull()}")
            println("Min: ${edtRating.minOrNull()}")
            println("Average: ${edtRating.average()}")
            println("Sum: ${edtRating.sum()}")

        }










        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}

private fun Any.putStringArrayListExtra(s: String, edtArtistNameList: ArrayList<Int>) {

}
